---
name: emil-design-eng
description: >
  Design engineering skill encoding Emil Kowalski's philosophy on UI polish, animation decisions,
  and the invisible details that make software feel great. Use this skill whenever the user asks
  about UI animations, transitions, hover states, button feedback, easing curves, CSS transforms,
  component polish, toast notifications, drawers, modals, popovers, tooltips, drag interactions,
  perceived performance, or anything related to making an interface feel right. Also trigger for
  requests to review UI code for animation quality, "how should this animate", "does this feel right",
  or any question about motion design in web interfaces. Covers both CSS and JS animation approaches
  (Framer Motion, WAAPI, springs). When in doubt, use this skill — it applies broadly to any
  front-end polish question.
---

# Design Engineering (Emil Kowalski)

Philosophy: taste is trained. Beauty is leverage. Unseen details compound. In a world where
everyone's software is "good enough", how it *feels* is the differentiator.

---

## Review Format

When reviewing UI code, always use a markdown table:

| Before | After | Why |
|--------|-------|-----|
| `transition: all 300ms` | `transition: transform 200ms ease-out` | Specify exact properties; avoid `all` |
| `transform: scale(0)` | `transform: scale(0.95); opacity: 0` | Nothing in the real world appears from nothing |
| `ease-in` on dropdown | `ease-out` with custom curve | `ease-in` feels sluggish; `ease-out` gives instant feedback |
| No `:active` state | `transform: scale(0.97)` on `:active` | Buttons must feel responsive to press |
| `transform-origin: center` on popover | `transform-origin: var(--radix-popover-content-transform-origin)` | Popovers scale from their trigger; modals stay centered |

Never use the "Before: / After:" list format. Always the table.

---

## Animation Decision Framework

### 1. Should this animate at all?

| Frequency | Decision |
|-----------|----------|
| 100+ times/day (keyboard shortcuts, command palette) | **No animation. Ever.** |
| Tens of times/day (hover, list navigation) | Remove or drastically reduce |
| Occasional (modals, drawers, toasts) | Standard animation |
| Rare/first-time (onboarding, celebrations) | Can add delight |

Never animate keyboard-initiated actions. Raycast has no open/close animation. That is optimal.

### 2. What is the purpose?

Every animation needs a clear answer to "why does this animate?" Valid purposes: spatial consistency,
state indication, explanation, feedback, preventing jarring changes. "It looks cool" for something
seen often is not valid.

### 3. What easing?

```
Element entering/exiting? → ease-out
Moving/morphing on screen? → ease-in-out
Hover/color change?       → ease
Constant motion?          → linear
Default                   → ease-out
```

**Always use custom curves** — built-in CSS easings are too weak:

```css
--ease-out:     cubic-bezier(0.23, 1, 0.32, 1);
--ease-in-out:  cubic-bezier(0.77, 0, 0.175, 1);
--ease-drawer:  cubic-bezier(0.32, 0.72, 0, 1);  /* iOS-like */
```

Resources: [easing.dev](https://easing.dev/) · [easings.co](https://easings.co/)

**Never use `ease-in` for UI.** It delays initial movement — the exact moment the user is watching.

### 4. How fast?

| Element | Duration |
|---------|----------|
| Button press feedback | 100–160ms |
| Tooltips, small popovers | 125–200ms |
| Dropdowns, selects | 150–250ms |
| Modals, drawers | 200–500ms |

**Rule: UI animations stay under 300ms.** A faster-spinning spinner makes the app *feel* faster even
when load time is identical. Perceived performance matters as much as actual performance.

---

## Review Checklist

| Issue | Fix |
|-------|-----|
| `transition: all` | Specify exact properties |
| `scale(0)` entry | Start from `scale(0.95)` + `opacity: 0` |
| `ease-in` on UI element | Switch to `ease-out` or custom curve |
| `transform-origin: center` on popover | Use Radix/Base UI CSS variable (modals: keep centered) |
| Animation on keyboard action | Remove entirely |
| Duration > 300ms on UI | Reduce to 150–250ms |
| Hover without media query | Add `@media (hover: hover) and (pointer: fine)` |
| Keyframes on rapidly-triggered element | Use CSS transitions (interruptible) |
| Framer Motion `x`/`y` props under load | Use `transform: "translateX()"` for GPU acceleration |
| Same enter/exit speed | Exit faster than enter |
| Elements all appear at once | Stagger 30–80ms between items |

---

## Quick Reference

For detailed implementation patterns, read the relevant reference file:

- **[references/components.md](references/components.md)** — buttons, popovers, tooltips, springs,
  CSS transforms, `clip-path` animations, gesture/drag interactions, stagger, `@starting-style`
- **[references/performance.md](references/performance.md)** — GPU acceleration, Framer Motion
  caveats, WAAPI, accessibility (`prefers-reduced-motion`), debugging, Sonner principles

Read a reference file when the user's question goes beyond the decision framework above —
e.g., implementing a specific pattern, fixing a specific component, or understanding *why* a
technique works.
# Component Patterns Reference

## Buttons

Add `transform: scale(0.97)` on `:active`. Instant feedback. Applies to any pressable element.

```css
.button {
  transition: transform 160ms ease-out;
}
.button:active {
  transform: scale(0.97);
}
```

## Never animate from scale(0)

Nothing in the real world disappears completely. Start from `scale(0.95)` + `opacity: 0`.

```css
/* Bad */  .entering { transform: scale(0); }
/* Good */ .entering { transform: scale(0.95); opacity: 0; }
```

## Popovers: origin-aware scaling

Popovers scale from their trigger. Modals stay centered — they're not anchored to a trigger.

```css
/* Radix UI */ .popover { transform-origin: var(--radix-popover-content-transform-origin); }
/* Base UI  */ .popover { transform-origin: var(--transform-origin); }
```

## Tooltips: skip delay on subsequent hovers

First tooltip delays (prevents accidents). Once one is open, subsequent hover = instant, no animation.

```css
.tooltip { transition: transform 125ms ease-out, opacity 125ms ease-out; }
.tooltip[data-starting-style], .tooltip[data-ending-style] { opacity: 0; transform: scale(0.97); }
.tooltip[data-instant] { transition-duration: 0ms; }
```

## Blur to mask imperfect crossfades

When a crossfade looks off, add `filter: blur(2px)` during transition. It bridges the visual gap
between two overlapping states, tricking the eye into seeing one smooth transformation.
Keep blur under 20px — heavy blur is expensive in Safari.

## @starting-style for CSS entry animations

Modern replacement for the `useEffect → setMounted` pattern:

```css
.toast {
  opacity: 1; transform: translateY(0);
  transition: opacity 400ms ease, transform 400ms ease;
  @starting-style { opacity: 0; transform: translateY(100%); }
}
```

## CSS Transitions > Keyframes for dynamic UI

Transitions retarget mid-animation. Keyframes restart from zero. Use transitions for anything
triggered repeatedly (toasts, toggled states).

---

## CSS Transform Mastery

### translateY with percentages

`translateY(100%)` = element's own height. Used by Sonner (toasts) and Vaul (drawers).
Prefer percentages over hardcoded pixels — adapts to content.

### scale() scales children

Unlike `width`/`height`, `scale()` proportionally scales all children. Feature, not bug.

### 3D transforms

```css
.wrapper { transform-style: preserve-3d; }
@keyframes orbit {
  from { transform: translate(-50%, -50%) rotateY(0deg)   translateZ(72px) rotateY(360deg); }
  to   { transform: translate(-50%, -50%) rotateY(360deg) translateZ(72px) rotateY(0deg);   }
}
```

---

## clip-path Animations

`clip-path: inset(top right bottom left)` — each value "eats" into the element from that side.

```css
.hidden  { clip-path: inset(0 100% 0 0); } /* hidden from right */
.visible { clip-path: inset(0 0   0 0); }
```

### Tabs with perfect color transitions

Duplicate the tab list. Style the copy as "active". Clip it so only the active tab shows.
Animate the clip on change. Timing individual color transitions can never match this.

### Hold-to-delete pattern

```css
.overlay { transition: clip-path 200ms ease-out; clip-path: inset(0 100% 0 0); }
.button:active .overlay { transition: clip-path 2s linear; clip-path: inset(0 0 0 0); }
```
Also add `scale(0.97)` on the button for press feedback.

### Image reveals on scroll

Start: `clip-path: inset(0 0 100% 0)`. Animate to `inset(0 0 0 0)` on viewport entry.
Use `IntersectionObserver` or Framer Motion `useInView({ once: true, margin: "-100px" })`.

### Comparison sliders

Overlay two images. Clip top one with `clip-path: inset(0 50% 0 0)`. Adjust right inset on drag.
Fully hardware-accelerated, no extra DOM elements.

---

## Springs

Springs feel natural because they simulate physics. No fixed duration — settle based on parameters.

### When to use

- Drag interactions with momentum
- Elements that should feel "alive"
- Gestures that can be interrupted mid-animation
- Decorative mouse-tracking interactions

### Mouse interactions

```jsx
import { useSpring } from 'framer-motion';

// Without spring: artificial, instant
const rotation = mouseX * 0.1;

// With spring: natural, has momentum
const springRotation = useSpring(mouseX * 0.1, { stiffness: 100, damping: 10 });
```

### Configuration

```js
// Apple's approach (easier to reason about)
{ type: "spring", duration: 0.5, bounce: 0.2 }

// Traditional physics (more control)
{ type: "spring", mass: 1, stiffness: 100, damping: 10 }
```

Keep bounce subtle (0.1–0.3). Avoid bounce in most UI contexts. Springs maintain velocity when
interrupted — CSS/keyframe animations restart from zero.

---

## Gesture & Drag

### Momentum-based dismissal

Don't require dragging past a threshold. Use velocity: `Math.abs(dragDistance) / elapsedTime`.
If velocity > ~0.11, dismiss regardless of distance. A quick flick should be enough.

### Damping at boundaries

When dragging past natural boundary, apply increasing friction. Real things slow down, not hard-stop.

### Pointer capture

Once drag starts, capture all pointer events so dragging continues if pointer leaves element bounds.

### Multi-touch protection

Ignore additional touch points after drag begins. Without this, switching fingers causes a jump.

---

## Stagger Animations

```css
.item { opacity: 0; transform: translateY(8px); animation: fadeIn 300ms ease-out forwards; }
.item:nth-child(1) { animation-delay: 0ms; }
.item:nth-child(2) { animation-delay: 50ms; }
.item:nth-child(3) { animation-delay: 100ms; }

@keyframes fadeIn { to { opacity: 1; transform: translateY(0); } }
```

Keep stagger delays 30–80ms. Never block interaction while stagger plays.

---

## Asymmetric Enter/Exit Timing

Slow where the user is deciding, fast where the system responds.

```css
.overlay              { transition: clip-path 200ms ease-out; } /* release: fast */
.button:active .overlay { transition: clip-path 2s linear; }     /* press: deliberate */
```
-e 


# Performance, Accessibility & Debugging

## Performance Rules

### Only animate transform and opacity

These skip layout and paint, running on the GPU. Animating `padding`, `margin`, `height`, `width`
triggers all three rendering steps — avoid.

### CSS variables on parents are expensive

Changing a CSS variable recalculates styles for all children. In a drawer with many items,
updating `--swipe-amount` on the container is slow. Update `transform` directly instead.

```js
// Bad:  triggers recalc on all children
element.style.setProperty('--swipe-amount', `${distance}px`);

// Good: only affects this element
element.style.transform = `translateY(${distance}px)`;
```

### Framer Motion `x`/`y` are NOT hardware-accelerated

Shorthand properties use `requestAnimationFrame` on the main thread. Use full `transform` string:

```jsx
// Drops frames when main thread is busy
<motion.div animate={{ x: 100 }} />

// Stays smooth — hardware accelerated
<motion.div animate={{ transform: "translateX(100px)" }} />
```

Real example: Vercel dashboard tab animation used Shared Layout Animations and dropped frames
during page loads. Switching to CSS animations fixed it.

### CSS animations beat JS under load

CSS animations run off the main thread. When the browser is loading a new page, Framer Motion
(`requestAnimationFrame`) drops frames. CSS animations stay smooth.

**Rule:** CSS for predetermined animations. JS for dynamic, interruptible ones.

### WAAPI: programmatic CSS-level performance

```js
element.animate(
  [{ clipPath: 'inset(0 0 100% 0)' }, { clipPath: 'inset(0 0 0 0)' }],
  { duration: 1000, fill: 'forwards', easing: 'cubic-bezier(0.77, 0, 0.175, 1)' }
);
```

Hardware-accelerated, interruptible, no library needed.

---

## Accessibility

### prefers-reduced-motion

Reduced motion = fewer and gentler, not zero. Keep opacity/color transitions that aid comprehension.
Remove movement and position animations.

```css
@media (prefers-reduced-motion: reduce) {
  .element { animation: fade 0.2s ease; /* no transform-based motion */ }
}
```

```jsx
const shouldReduceMotion = useReducedMotion();
const closedX = shouldReduceMotion ? 0 : '-100%';
```

### Touch device hover states

```css
@media (hover: hover) and (pointer: fine) {
  .element:hover { transform: scale(1.05); }
}
```

Touch devices trigger hover on tap. Gate hover animations behind this or they fire accidentally.

---

## Debugging

### Slow motion testing

Increase duration to 2–5× normal, or use Chrome DevTools animation inspector.

Look for:
- Two distinct states overlapping during crossfade (try blur)
- Easing that starts/stops abruptly
- Wrong `transform-origin`
- Multiple animated properties out of sync

### Frame-by-frame

Chrome DevTools > Animations panel. Step through frame by frame to spot timing issues between
coordinated properties.

### Test on real devices

Touch interactions (drawers, swipe) must be tested on physical devices, not simulators.
Connect via USB, visit local dev server by IP, use Safari remote devtools.

### Review your work the next day

You notice imperfections the next day that you missed during development. Play animations in slow
motion to catch issues invisible at full speed.

---

## The Sonner Principles (Building Loved Components)

From building Sonner (13M+ weekly npm downloads):

1. **DX is key.** No hooks, no context, no setup. `<Toaster />` once, `toast()` anywhere.
2. **Good defaults > options.** Ship beautiful out of the box. Most users never customize.
3. **Naming creates identity.** "Sonner" (French: "to ring") > "react-toast". Sacrifice discoverability for memorability.
4. **Handle edge cases invisibly.** Pause timers when tab is hidden. Fill gaps between stacked toasts with pseudo-elements. Users never notice. That's the point.
5. **Transitions, not keyframes, for dynamic UI.** Toasts are added rapidly. Keyframes restart from zero on interruption.
6. **Great documentation.** Let people touch it before they use it. Interactive examples lower adoption friction.

### Cohesion matters

Sonner feels right because everything is in harmony: easing, duration, visual design, page design,
and the name all fit the same vibe. It's slightly slower than typical UI and uses `ease` over
`ease-out` to feel more elegant.

When choosing values, consider the component's personality. Playful → bouncier. Professional dashboard → crisp and fast.

### The opacity + height combination

When items enter/exit a list, opacity and height must work together. There is no formula.
Adjust until it feels right.
