import { useState, useEffect, useRef, useCallback } from "react";

// ═══════════════════════════════════════════
// Design tokens from existing palette
// ═══════════════════════════════════════════
const T = {
  bgApp: "#14110F",
  bgElevated: "#1C1714",
  surfaceSoft: "#241E1A",
  surfaceDeep: "#2d241e",
  lineMuted: "#3A3028",
  lineStrong: "#4a3d33",
  textPrimary: "#E7DDCC",
  textSecondary: "#B7A892",
  textFaint: "#8E806C",
  accentClay: "#8C563E",
  accentClayLight: "#A86D50",
  accentCeladon: "#66705F",
  accentGold: "#c9a84c",
};

// Wu Xing element definitions
const ELEMENTS = [
  {
    id: "wood",
    zh: "木",
    en: "Wood",
    color: "#4E7E38",
    colorMuted: "#3a5e2a",
    tea: "Green Tea",
    teaZh: "绿茶",
    hasSubs: false,
    params: { temp: 80, ratio: "5g / 80ml", rinse: false, schedule: [8, 10, 12, 15, 20, 28, 38] },
    note: "No rinse, lower temp. The first steep is the brightest.",
  },
  {
    id: "fire",
    zh: "火",
    en: "Fire",
    color: "#96382E",
    colorMuted: "#7a2e26",
    tea: "Black Tea",
    teaZh: "红茶",
    hasSubs: false,
    params: { temp: 95, ratio: "5.5g / 100ml", rinse: false, schedule: [10, 12, 15, 18, 24, 32, 45, 62] },
    note: "Start steady, then widen as the sweetness softens.",
  },
  {
    id: "earth",
    zh: "土",
    en: "Earth",
    color: "#967428",
    colorMuted: "#7a5e20",
    tea: "Oolong",
    teaZh: "烏龍",
    hasSubs: true,
    subs: [
      {
        id: "light-oolong",
        label: "Light",
        labelZh: "清香",
        params: { temp: 95, ratio: "5.5g / 100ml", rinse: false, schedule: [10, 12, 14, 18, 24, 32, 45, 60] },
        note: "No rinse — preserve the first flush of fragrance.",
      },
      {
        id: "dark-oolong",
        label: "Dark",
        labelZh: "浓香",
        params: { temp: 100, ratio: "7g / 100ml", rinse: true, schedule: [8, 10, 12, 15, 20, 28, 38, 55] },
        note: "Let the roast open gradually. Early steeps stay short.",
      },
    ],
  },
  {
    id: "metal",
    zh: "金",
    en: "Metal",
    color: "#B0AAA0",
    colorMuted: "#8a857d",
    tea: "White Tea",
    teaZh: "白茶",
    hasSubs: true,
    subs: [
      {
        id: "fresh-white",
        label: "Fresh",
        labelZh: "新",
        params: { temp: 88, ratio: "5g / 100ml", rinse: false, schedule: [12, 15, 18, 22, 28, 36, 50, 70] },
        note: "White tea rewards patience and a gentle, slow curve.",
      },
      {
        id: "aged-white",
        label: "Aged",
        labelZh: "老",
        params: { temp: 95, ratio: "5g / 100ml", rinse: true, schedule: [10, 12, 15, 20, 28, 38, 55, 75] },
        note: "Higher heat unlocks the jujube and wood notes.",
      },
    ],
  },
  {
    id: "water",
    zh: "水",
    en: "Water",
    color: "#385E66",
    colorMuted: "#2c4a52",
    tea: "Pu-erh",
    teaZh: "普洱",
    hasSubs: true,
    subs: [
      {
        id: "sheng",
        label: "Sheng",
        labelZh: "生",
        params: { temp: 95, ratio: "5.5g / 100ml", rinse: true, schedule: [6, 8, 10, 12, 16, 22, 30, 45] },
        note: "Short, careful steeps keep the bitterness in check.",
      },
      {
        id: "shou",
        label: "Shou",
        labelZh: "熟",
        params: { temp: 100, ratio: "6.4g / 110ml", rinse: true, schedule: [10, 12, 15, 18, 24, 32, 45, 60] },
        note: "A double rinse clears pile notes. Let the middle steeps linger.",
      },
    ],
  },
];

// ═══════════════════════════════════════════
// Wheel Component
// ═══════════════════════════════════════════
function WuXingWheel({ selected, onSelect, onBrew }) {
  const [hovered, setHovered] = useState(null);
  const [subChoice, setSubChoice] = useState(null);

  const CX = 195, CY = 195, ORBIT_R = 125, BUBBLE_R = 38;
  const active = selected ? ELEMENTS.find((e) => e.id === selected) : null;
  const centerEl = hovered ? ELEMENTS.find((e) => e.id === hovered) : active;

  const handleSelect = (el) => {
    if (selected === el.id && !el.hasSubs) {
      onBrew(el, el.params, el.tea, el.teaZh);
    } else if (selected === el.id && el.hasSubs && subChoice) {
      const sub = el.subs.find((s) => s.id === subChoice);
      onBrew(el, sub.params, `${sub.label} ${el.tea}`, el.teaZh, sub.note);
    } else {
      onSelect(el.id);
      setSubChoice(null);
    }
  };

  const handleSub = (el, sub) => {
    setSubChoice(sub.id);
    setTimeout(() => {
      onBrew(el, sub.params, `${sub.label} ${el.tea}`, el.teaZh, sub.note);
    }, 300);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 20 }}>
      <svg viewBox="0 0 390 390" style={{ width: "100%", maxWidth: 390 }}>
        {/* Orbit ring */}
        <circle cx={CX} cy={CY} r={ORBIT_R} fill="none" stroke={T.lineMuted} strokeWidth="1" strokeDasharray="3 10" opacity="0.5" />

        {/* Element bubbles */}
        {ELEMENTS.map((el, i) => {
          const angle = (i / 5) * 2 * Math.PI - Math.PI / 2;
          const x = CX + Math.cos(angle) * ORBIT_R;
          const y = CY + Math.sin(angle) * ORBIT_R;
          const isSelected = selected === el.id;
          const isDimmed = selected && !isSelected;

          return (
            <g
              key={el.id}
              style={{ cursor: "pointer", transition: "opacity 0.4s ease" }}
              opacity={isDimmed ? 0.3 : 1}
              onClick={() => handleSelect(el)}
              onMouseEnter={() => setHovered(el.id)}
              onMouseLeave={() => setHovered(null)}
            >
              {/* Shadow */}
              <circle cx={x + 1} cy={y + 3} r={BUBBLE_R + 1} fill="rgba(0,0,0,0.35)" />
              {/* Main bubble */}
              <circle cx={x} cy={y} r={BUBBLE_R} fill={el.color} />
              {/* Inner glow */}
              <circle cx={x} cy={y} r={BUBBLE_R - 1.5} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
              {/* Active ring */}
              {isSelected && (
                <circle
                  cx={x} cy={y} r={BUBBLE_R + 6}
                  fill="none" stroke={el.color} strokeWidth="1.5" opacity="0.6"
                  style={{ animation: "pulse 2s ease-in-out infinite" }}
                />
              )}
              {/* Chinese character */}
              <text x={x} y={y - 4} textAnchor="middle" dominantBaseline="middle"
                fill={T.textPrimary} fontSize="20" fontWeight="700"
                fontFamily="'Noto Serif SC', serif" style={{ pointerEvents: "none" }}>
                {el.zh}
              </text>
              {/* English label */}
              <text x={x} y={y + 16} textAnchor="middle" dominantBaseline="middle"
                fill={T.textPrimary} fontSize="9" opacity="0.65"
                fontFamily="'DM Sans', sans-serif" letterSpacing="0.04em"
                style={{ pointerEvents: "none" }}>
                {el.en}
              </text>
            </g>
          );
        })}

        {/* Center circle */}
        <circle cx={CX} cy={CY} r={selected ? 52 : 46} fill="rgba(16,13,11,0.97)"
          style={{ transition: "r 0.3s ease" }} />
        <circle cx={CX} cy={CY} r={selected ? 52 : 46} fill="none"
          stroke={selected ? (active?.color || T.lineMuted) : T.lineMuted}
          strokeWidth="0.75" opacity={selected ? 0.5 : 0.4}
          style={{ transition: "all 0.3s ease" }} />

        {/* Center content */}
        {!selected && !centerEl && (
          <text x={CX} y={CY} textAnchor="middle" dominantBaseline="middle"
            fill={T.textPrimary} fontSize="28" fontWeight="700" opacity="0.18"
            fontFamily="'Noto Serif SC', serif">
            茶
          </text>
        )}
        {centerEl && !selected && (
          <>
            <text x={CX} y={CY - 8} textAnchor="middle" dominantBaseline="middle"
              fill={T.textPrimary} fontSize="18" fontWeight="700"
              fontFamily="'Noto Serif SC', serif">
              {centerEl.teaZh}
            </text>
            <text x={CX} y={CY + 14} textAnchor="middle" dominantBaseline="middle"
              fill={T.textSecondary} fontSize="9"
              fontFamily="'DM Sans', sans-serif">
              {centerEl.tea}
            </text>
          </>
        )}
        {selected && active && !active.hasSubs && (
          <>
            <text x={CX} y={CY - 12} textAnchor="middle" dominantBaseline="middle"
              fill={T.textPrimary} fontSize="18" fontWeight="700"
              fontFamily="'Noto Serif SC', serif">
              {active.teaZh}
            </text>
            <text x={CX} y={CY + 8} textAnchor="middle" dominantBaseline="middle"
              fill={T.textSecondary} fontSize="9"
              fontFamily="'DM Sans', sans-serif">
              Tap to brew
            </text>
          </>
        )}
        {selected && active && active.hasSubs && (
          <>
            <text x={CX} y={CY - 26} textAnchor="middle" dominantBaseline="middle"
              fill={T.textPrimary} fontSize="15" fontWeight="700"
              fontFamily="'Noto Serif SC', serif">
              {active.teaZh}
            </text>
            <line x1={CX - 28} y1={CY - 10} x2={CX + 28} y2={CY - 10}
              stroke={T.lineMuted} strokeWidth="0.5" opacity="0.5" />
            {active.subs.map((sub, si) => (
              <text key={sub.id} x={CX} y={CY + 8 + si * 22}
                textAnchor="middle" dominantBaseline="middle"
                fill={subChoice === sub.id ? T.textPrimary : T.textSecondary}
                fontSize="12" fontWeight={subChoice === sub.id ? "600" : "400"}
                fontFamily="'DM Sans', sans-serif"
                style={{ cursor: "pointer", transition: "fill 0.2s" }}
                onClick={(e) => { e.stopPropagation(); handleSub(active, sub); }}>
                {sub.label}
              </text>
            ))}
          </>
        )}
      </svg>
    </div>
  );
}

// ═══════════════════════════════════════════
// Timer Component
// ═══════════════════════════════════════════
function BrewTimer({ tea, params, onEnd, note }) {
  const [infusion, setInfusion] = useState(0);
  const [phase, setPhase] = useState("idle"); // idle, brewing, paused, between
  const [remaining, setRemaining] = useState(params.schedule[0]);
  const [total, setTotal] = useState(params.schedule[0]);
  const [adjustment, setAdjustment] = useState(0);
  const intervalRef = useRef(null);
  const startTimeRef = useRef(null);
  const remainingAtPauseRef = useRef(null);

  const currentScheduleTime = (idx) => {
    if (idx < params.schedule.length) return params.schedule[idx];
    const last = params.schedule[params.schedule.length - 1];
    return Math.min(last + (idx - params.schedule.length + 1) * 10, 120);
  };

  const startBrew = useCallback(() => {
    const dur = currentScheduleTime(infusion) + adjustment;
    setTotal(dur);
    setRemaining(dur);
    setPhase("brewing");
    startTimeRef.current = Date.now();
    remainingAtPauseRef.current = null;

    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      const elapsed = (Date.now() - startTimeRef.current) / 1000;
      const left = Math.max(0, dur - elapsed);
      setRemaining(Math.ceil(left));
      if (left <= 0) {
        clearInterval(intervalRef.current);
        setPhase("between");
      }
    }, 100);
  }, [infusion, adjustment]);

  const pause = () => {
    if (phase !== "brewing") return;
    clearInterval(intervalRef.current);
    remainingAtPauseRef.current = remaining;
    setPhase("paused");
  };

  const resume = () => {
    if (phase !== "paused") return;
    const dur = remainingAtPauseRef.current || remaining;
    setPhase("brewing");
    startTimeRef.current = Date.now();

    intervalRef.current = setInterval(() => {
      const elapsed = (Date.now() - startTimeRef.current) / 1000;
      const left = Math.max(0, dur - elapsed);
      setRemaining(Math.ceil(left));
      if (left <= 0) {
        clearInterval(intervalRef.current);
        setPhase("between");
      }
    }, 100);
  };

  const nextInfusion = () => {
    setInfusion((i) => i + 1);
    setAdjustment(0);
    setPhase("idle");
  };

  useEffect(() => {
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  const progress = phase === "brewing" || phase === "paused" ? (total - remaining) / total : phase === "between" ? 1 : 0;
  const circumference = 2 * Math.PI * 120;
  const dashOffset = circumference * (1 - progress);

  const nextIdx = infusion + 1;
  const nextBase = currentScheduleTime(nextIdx);
  const nextTime = nextBase + adjustment;

  return (
    <div style={{
      display: "flex", flexDirection: "column", alignItems: "center",
      padding: "0 24px", height: "100%", position: "relative",
    }}>
      {/* Top bar */}
      <div style={{
        display: "flex", justifyContent: "space-between", alignItems: "center",
        width: "100%", padding: "16px 0",
      }}>
        <span style={{ color: T.textSecondary, fontSize: 14, fontFamily: "'DM Sans', sans-serif" }}>
          {tea.name}
          <span style={{ fontFamily: "'Noto Serif SC', serif", marginLeft: 6, opacity: 0.6 }}>
            {tea.zh}
          </span>
        </span>
        <span onClick={onEnd} style={{
          color: T.textFaint, fontSize: 13, cursor: "pointer",
          fontFamily: "'DM Sans', sans-serif",
          padding: "8px 0 8px 16px",
        }}>End</span>
      </div>

      {/* Infusion label */}
      <div style={{ color: T.textFaint, fontSize: 12, marginTop: 16, marginBottom: 24, fontFamily: "'DM Sans', sans-serif", letterSpacing: "0.05em" }}>
        {phase === "between" ? `Infusion ${infusion + 1} complete` : `Infusion ${infusion + 1}`}
      </div>

      {/* Timer ring */}
      {phase !== "between" ? (
        <div style={{ position: "relative", width: 260, height: 260 }}>
          <svg viewBox="0 0 260 260" style={{ width: "100%", transform: "rotate(-90deg)" }}>
            <circle cx="130" cy="130" r="120" fill="none" stroke={T.lineMuted} strokeWidth="3" opacity="0.25" />
            <circle cx="130" cy="130" r="120" fill="none"
              stroke={phase === "brewing" ? T.accentCeladon : T.textFaint}
              strokeWidth="3" strokeLinecap="round"
              strokeDasharray={circumference} strokeDashoffset={dashOffset}
              style={{ transition: "stroke-dashoffset 0.15s linear" }} />
          </svg>
          <div style={{
            position: "absolute", inset: 0, display: "flex", flexDirection: "column",
            alignItems: "center", justifyContent: "center",
          }}>
            <span style={{
              fontSize: remaining > 99 ? 48 : 56, fontWeight: 700, color: T.textPrimary,
              fontFamily: "'DM Sans', sans-serif", lineHeight: 1,
            }}>
              {phase === "idle" ? currentScheduleTime(infusion) : remaining}
            </span>
            <span style={{ fontSize: 12, color: T.textFaint, marginTop: 6, fontFamily: "'DM Sans', sans-serif" }}>
              seconds
            </span>
          </div>
        </div>
      ) : (
        <div style={{
          display: "flex", flexDirection: "column", alignItems: "center",
          justifyContent: "center", height: 260,
        }}>
          <span style={{ fontSize: 48, fontWeight: 700, color: T.textPrimary, fontFamily: "'DM Sans', sans-serif" }}>
            {currentScheduleTime(infusion)}s
          </span>
          <span style={{ fontSize: 12, color: T.textFaint, marginTop: 4, fontFamily: "'DM Sans', sans-serif" }}>
            brewed
          </span>
        </div>
      )}

      {/* Controls */}
      <div style={{ marginTop: 32, display: "flex", flexDirection: "column", alignItems: "center", gap: 16, width: "100%" }}>
        {phase === "idle" && (
          <button onClick={startBrew} style={{
            width: 64, height: 64, borderRadius: "50%",
            background: T.accentClay, border: "none", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: `0 4px 20px rgba(140,86,62,0.3)`,
          }}>
            <div style={{ width: 0, height: 0, borderTop: "10px solid transparent", borderBottom: "10px solid transparent", borderLeft: `16px solid ${T.textPrimary}`, marginLeft: 3 }} />
          </button>
        )}
        {phase === "brewing" && (
          <button onClick={pause} style={{
            width: 56, height: 56, borderRadius: "50%",
            background: T.surfaceSoft, border: `1px solid ${T.lineMuted}`,
            cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <div style={{ display: "flex", gap: 4 }}>
              <div style={{ width: 4, height: 16, background: T.textSecondary, borderRadius: 1 }} />
              <div style={{ width: 4, height: 16, background: T.textSecondary, borderRadius: 1 }} />
            </div>
          </button>
        )}
        {phase === "paused" && (
          <button onClick={resume} style={{
            width: 56, height: 56, borderRadius: "50%",
            background: T.surfaceSoft, border: `1px solid ${T.accentClay}`,
            cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <div style={{ width: 0, height: 0, borderTop: "8px solid transparent", borderBottom: "8px solid transparent", borderLeft: `14px solid ${T.textPrimary}`, marginLeft: 2 }} />
          </button>
        )}
        {phase === "between" && (
          <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Next infusion preview */}
            <div style={{
              background: T.surfaceSoft, borderRadius: 18, padding: "16px 20px",
              display: "flex", justifyContent: "space-between", alignItems: "center",
            }}>
              <div>
                <div style={{ color: T.textFaint, fontSize: 11, marginBottom: 4, fontFamily: "'DM Sans', sans-serif" }}>
                  Next · Infusion {nextIdx + 1}
                </div>
                <span style={{ color: T.textPrimary, fontSize: 24, fontWeight: 600, fontFamily: "'DM Sans', sans-serif" }}>
                  {nextTime}s
                </span>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button onClick={() => setAdjustment((a) => a - 3)} style={{
                  background: T.bgElevated, border: `1px solid ${T.lineMuted}`,
                  borderRadius: 10, padding: "6px 12px", color: T.textSecondary,
                  cursor: "pointer", fontSize: 12, fontFamily: "'DM Sans', sans-serif",
                }}>-3s</button>
                <button onClick={() => setAdjustment((a) => a + 3)} style={{
                  background: T.bgElevated, border: `1px solid ${T.lineMuted}`,
                  borderRadius: 10, padding: "6px 12px", color: T.textSecondary,
                  cursor: "pointer", fontSize: 12, fontFamily: "'DM Sans', sans-serif",
                }}>+3s</button>
              </div>
            </div>

            <button onClick={nextInfusion} style={{
              width: "100%", padding: "16px 0", borderRadius: 18,
              background: T.accentClay, border: "none", color: T.textPrimary,
              fontSize: 15, fontWeight: 600, cursor: "pointer",
              fontFamily: "'DM Sans', sans-serif",
              boxShadow: `0 4px 20px rgba(140,86,62,0.25)`,
            }}>
              Brew Next
            </button>
          </div>
        )}
      </div>

      {/* Schedule bar */}
      <div style={{
        marginTop: "auto", paddingBottom: 20, width: "100%",
      }}>
        {note && phase === "idle" && infusion === 0 && (
          <div style={{
            color: T.textFaint, fontSize: 11, fontStyle: "italic",
            textAlign: "center", marginBottom: 16, lineHeight: 1.5,
            fontFamily: "'DM Sans', sans-serif", maxWidth: 280, margin: "0 auto 16px",
          }}>
            {note}
          </div>
        )}
        <div style={{
          background: T.surfaceSoft, borderRadius: 14, padding: "12px 16px",
        }}>
          <div style={{ color: T.textFaint, fontSize: 10, marginBottom: 6, fontFamily: "'DM Sans', sans-serif" }}>
            Schedule
          </div>
          <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
            {params.schedule.map((s, i) => (
              <span key={i} style={{
                fontSize: 12, fontFamily: "'DM Sans', sans-serif",
                color: i < infusion ? T.accentCeladon : i === infusion ? T.textPrimary : T.textFaint,
                fontWeight: i === infusion ? 600 : 400,
                opacity: i < infusion ? 0.6 : 1,
              }}>
                {s}s{i < params.schedule.length - 1 ? " · " : ""}
              </span>
            ))}
          </div>
        </div>
        <div style={{
          color: T.textFaint, fontSize: 11, textAlign: "center", marginTop: 10,
          fontFamily: "'DM Sans', sans-serif",
        }}>
          {params.temp}°C · {params.ratio} · {params.rinse ? "Rinse" : "No rinse"}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
// AI Advisor Screen
// ═══════════════════════════════════════════
function AIAdvisor({ onBrew }) {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const mockIdentify = () => {
    setLoading(true);
    setTimeout(() => {
      setResult({
        name: "Da Hong Pao",
        nameZh: "大红袍",
        category: "Yancha · Dark Oolong · Earth 土",
        params: { temp: 100, ratio: "7g / 100ml", rinse: true, schedule: [8, 10, 12, 15, 20, 28, 38, 55] },
        note: "Let the roast open gradually. Early steeps stay short, later ones climb with confidence.",
      });
      setLoading(false);
    }, 1200);
  };

  return (
    <div style={{ padding: "0 24px", display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{
        background: T.surfaceSoft, borderRadius: 20, padding: "20px 20px 16px",
        marginTop: 20,
      }}>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Describe your tea..."
          style={{
            width: "100%", background: "transparent", border: "none",
            color: T.textPrimary, fontSize: 15, outline: "none",
            fontFamily: "'DM Sans', sans-serif", marginBottom: 8,
          }}
        />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
          <span style={{ color: T.textFaint, fontSize: 11, fontFamily: "'DM Sans', sans-serif", lineHeight: 1.5 }}>
            e.g. "Da Hong Pao from 2023"<br />or "light floral oolong, tightly rolled"
          </span>
          <button onClick={mockIdentify} style={{
            width: 40, height: 32, borderRadius: 12,
            background: T.accentClay, border: "none", cursor: "pointer",
            color: T.textPrimary, fontSize: 16, fontWeight: 700,
            fontFamily: "'DM Sans', sans-serif",
          }}>→</button>
        </div>
      </div>

      {loading && (
        <div style={{ textAlign: "center", padding: 40, color: T.textFaint, fontSize: 13, fontFamily: "'DM Sans', sans-serif" }}>
          <div style={{ animation: "pulse 1.5s ease-in-out infinite" }}>Identifying your tea...</div>
        </div>
      )}

      {result && !loading && (
        <div style={{
          background: T.bgElevated, borderRadius: 20, padding: 24,
          border: `1px solid ${T.lineMuted}40`,
        }}>
          <div style={{ fontSize: 17, fontWeight: 600, color: T.textPrimary, fontFamily: "'DM Sans', sans-serif", marginBottom: 4 }}>
            {result.name}
            <span style={{ fontFamily: "'Noto Serif SC', serif", marginLeft: 8, opacity: 0.7 }}>
              {result.nameZh}
            </span>
          </div>
          <div style={{ fontSize: 11, color: T.textSecondary, marginBottom: 16, fontFamily: "'DM Sans', sans-serif" }}>
            {result.category}
          </div>
          <div style={{ height: 1, background: T.lineMuted, opacity: 0.3, marginBottom: 16 }} />

          <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: "8px 16px", fontSize: 13, fontFamily: "'DM Sans', sans-serif" }}>
            <span style={{ color: T.textFaint }}>Temperature</span>
            <span style={{ color: T.textSecondary }}>{result.params.temp}°C</span>
            <span style={{ color: T.textFaint }}>Leaf ratio</span>
            <span style={{ color: T.textSecondary }}>{result.params.ratio}</span>
            <span style={{ color: T.textFaint }}>Rinse</span>
            <span style={{ color: T.textSecondary }}>{result.params.rinse ? "Yes" : "No"}</span>
          </div>

          <div style={{ marginTop: 16, fontSize: 11, color: T.textFaint, fontFamily: "'DM Sans', sans-serif" }}>
            {result.params.schedule.map((s) => `${s}s`).join(" · ")}
          </div>

          {result.note && (
            <div style={{ marginTop: 12, fontSize: 11, color: T.textFaint, fontStyle: "italic", lineHeight: 1.5, fontFamily: "'DM Sans', sans-serif" }}>
              {result.note}
            </div>
          )}

          <button onClick={() => onBrew(
            { id: "ai", color: T.accentClay },
            result.params,
            result.name,
            result.nameZh,
            result.note,
          )} style={{
            width: "100%", padding: "14px 0", borderRadius: 16, marginTop: 20,
            background: T.accentClay, border: "none", color: T.textPrimary,
            fontSize: 15, fontWeight: 600, cursor: "pointer",
            fontFamily: "'DM Sans', sans-serif",
            boxShadow: `0 4px 20px rgba(140,86,62,0.25)`,
          }}>
            Start Brewing
          </button>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════
// Custom Mode Screen
// ═══════════════════════════════════════════
function CustomMode({ onBrew }) {
  const [name, setName] = useState("");
  const [temp, setTemp] = useState(95);
  const [ratio, setRatio] = useState("6g / 100ml");
  const [rinse, setRinse] = useState(true);

  const params = {
    temp, ratio, rinse,
    schedule: [10, 10, 12, 15, 20, 28, 40, 55],
  };

  const fieldStyle = {
    width: "100%", background: T.surfaceSoft, border: "none", borderRadius: 14,
    padding: "14px 16px", color: T.textPrimary, fontSize: 15, outline: "none",
    fontFamily: "'DM Sans', sans-serif", boxSizing: "border-box",
  };

  const labelStyle = {
    color: T.textFaint, fontSize: 11, fontWeight: 500, marginBottom: 6,
    fontFamily: "'DM Sans', sans-serif", letterSpacing: "0.03em",
  };

  return (
    <div style={{ padding: "20px 24px", display: "flex", flexDirection: "column", gap: 16 }}>
      <div>
        <div style={labelStyle}>Tea Name</div>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="My tea..." style={fieldStyle} />
      </div>
      <div>
        <div style={labelStyle}>Water Temperature</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {[80, 85, 90, 95, 100].map((t) => (
            <button key={t} onClick={() => setTemp(t)} style={{
              padding: "10px 16px", borderRadius: 12, border: `1px solid ${temp === t ? T.accentClay : T.lineMuted}`,
              background: temp === t ? T.accentClay + "22" : T.surfaceSoft,
              color: temp === t ? T.textPrimary : T.textSecondary,
              cursor: "pointer", fontSize: 14, fontFamily: "'DM Sans', sans-serif",
            }}>{t}°C</button>
          ))}
        </div>
      </div>
      <div>
        <div style={labelStyle}>Leaf Ratio</div>
        <input value={ratio} onChange={(e) => setRatio(e.target.value)} style={fieldStyle} />
      </div>
      <div>
        <div style={labelStyle}>Rinse</div>
        <div style={{ display: "flex", gap: 8 }}>
          {[true, false].map((v) => (
            <button key={String(v)} onClick={() => setRinse(v)} style={{
              padding: "10px 20px", borderRadius: 12,
              border: `1px solid ${rinse === v ? T.accentClay : T.lineMuted}`,
              background: rinse === v ? T.accentClay + "22" : T.surfaceSoft,
              color: rinse === v ? T.textPrimary : T.textSecondary,
              cursor: "pointer", fontSize: 14, fontFamily: "'DM Sans', sans-serif",
            }}>{v ? "Yes" : "No"}</button>
          ))}
        </div>
      </div>
      <div>
        <div style={labelStyle}>Infusion Schedule</div>
        <div style={{ ...fieldStyle, color: T.textSecondary, fontSize: 13 }}>
          {params.schedule.map((s) => `${s}s`).join(" · ")}
        </div>
      </div>

      <button onClick={() => onBrew(
        { id: "custom", color: T.accentClay },
        params,
        name || "Custom Brew",
        "",
      )} style={{
        width: "100%", padding: "16px 0", borderRadius: 18, marginTop: 8,
        background: T.accentClay, border: "none", color: T.textPrimary,
        fontSize: 15, fontWeight: 600, cursor: "pointer",
        fontFamily: "'DM Sans', sans-serif",
        boxShadow: `0 4px 20px rgba(140,86,62,0.25)`,
      }}>
        Start Brewing
      </button>
    </div>
  );
}

// ═══════════════════════════════════════════
// Main App
// ═══════════════════════════════════════════
export default function GongfuCha() {
  const [tab, setTab] = useState("wheel"); // wheel, ai, custom
  const [selected, setSelected] = useState(null);
  const [brewing, setBrewing] = useState(null);

  const handleBrew = (element, params, teaName, teaZh, note) => {
    setBrewing({ element, params, tea: { name: teaName, zh: teaZh }, note });
  };

  const handleEnd = () => {
    setBrewing(null);
    setSelected(null);
  };

  const tabs = [
    { id: "wheel", label: "Wheel", icon: "◎" },
    { id: "ai", label: "AI Advisor", icon: "✦" },
    { id: "custom", label: "Custom", icon: "⊞" },
  ];

  return (
    <div style={{
      width: "100%",
      maxWidth: 390,
      margin: "0 auto",
      height: "100vh",
      background: T.bgApp,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      fontFamily: "'DM Sans', sans-serif",
      position: "relative",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Noto+Serif+SC:wght@400;700&display=swap');
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { display: none; }
      `}</style>

      {/* Brewing screen */}
      {brewing ? (
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          <BrewTimer
            tea={brewing.tea}
            params={brewing.params}
            note={brewing.note}
            onEnd={handleEnd}
          />
        </div>
      ) : (
        <>
          {/* Header */}
          <div style={{
            textAlign: "center", padding: "24px 0 8px",
            flexShrink: 0,
          }}>
            <div style={{
              fontSize: 22, fontWeight: 700, color: T.textPrimary,
              fontFamily: "'Noto Serif SC', serif",
              letterSpacing: "0.08em",
            }}>功夫茶</div>
            <div style={{
              fontSize: 11, color: T.textFaint, marginTop: 4,
              fontFamily: "'DM Sans', sans-serif",
              letterSpacing: "0.06em",
            }}>
              {tab === "wheel" ? "Gongfu Cha" : tab === "ai" ? "AI Advisor" : "Custom Brew"}
            </div>
          </div>

          {/* Content */}
          <div style={{ flex: 1, overflow: "auto" }}>
            {tab === "wheel" && (
              <WuXingWheel
                selected={selected}
                onSelect={setSelected}
                onBrew={handleBrew}
              />
            )}
            {tab === "ai" && <AIAdvisor onBrew={handleBrew} />}
            {tab === "custom" && <CustomMode onBrew={handleBrew} />}
          </div>

          {/* Tab bar */}
          <div style={{
            display: "flex", justifyContent: "space-around",
            padding: "16px 0 28px",
            background: T.bgElevated,
            borderTop: `1px solid ${T.lineMuted}40`,
            flexShrink: 0,
          }}>
            {tabs.map((t) => (
              <button key={t.id} onClick={() => { setTab(t.id); setSelected(null); }}
                style={{
                  background: "none", border: "none", cursor: "pointer",
                  display: "flex", flexDirection: "column", alignItems: "center", gap: 4,
                  padding: "4px 16px",
                }}>
                <span style={{
                  fontSize: 18, color: tab === t.id ? T.accentClay : T.textFaint,
                  transition: "color 0.2s",
                }}>{t.icon}</span>
                <span style={{
                  fontSize: 10, fontWeight: tab === t.id ? 600 : 400,
                  color: tab === t.id ? T.textPrimary : T.textFaint,
                  fontFamily: "'DM Sans', sans-serif",
                  transition: "color 0.2s",
                }}>{t.label}</span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
