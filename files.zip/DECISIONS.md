# Gongfu Cha — Redesign Decisions (April 2026)

Planning session for a complete rebuild of the Gongfu Cha tea brewing app. This document captures every decision made, the reasoning behind it, and what to carry forward.

---

## 1. Why a Rebuild (Not a Refactor)

The existing Vue 3 + Vite PWA had accumulated too much design debt across 7 sprints of rapid AI-assisted development. The core problems were styling inconsistency, no shared spatial grammar between screens, and a SettleScreen that solved the wrong problem. The codebase's own `redesign-2026.md` was 800 lines of accumulated fixes — when the fix list is longer than the feature list, it's time to restart.

The previous codebase had working logic that was sound (timer, session management, tea presets), but every screen was designed in isolation without a design system. The decision was made to start fresh with a design-first approach, building from wireframes before writing any production code.

---

## 2. Tech Stack

**Decision: Next.js + React + Tailwind + Framer Motion**

Rationale and caveats:
- Next.js provides both frontend and a thin API route for the OpenRouter AI call. A Vite + React SPA would also work — Next.js is chosen for Vercel deployment convenience and future growth (user accounts, tea journal), not because the current feature set requires it. If the app stays simple, Vite + React is the lighter option.
- Tailwind for utility-driven styling. Note: the existing app's bespoke CSS with custom properties produced a more atmospheric result. Tailwind trades some craft for speed. This is an acceptable tradeoff for a v1 rebuild, but the app's emotional quality matters — don't let Tailwind flatten the design into generic utility-class output.
- Framer Motion for the wheel interaction and page transitions. If the wheel ends up being tap-to-select (not spin/drag), CSS animations may suffice and Framer Motion becomes optional.
- **OpenRouter** for AI tea identification (not Claude API directly). Server-side route, keeps API key safe, gives model flexibility.
- **No database for v1.** Tea presets are a static JSON dataset. Brewing params and session state use localStorage. Add persistence later if user history/favorites are needed.
- **No Zustand or external state library.** React's built-in useState/useContext handles the state shape (selected tea, brewing params, current infusion, timer state). Add a state library only when it hurts.
- **PWA deferred.** Build the web app first. Add service worker, manifest, and offline caching as polish once the core experience works.

---

## 3. Core Concept: Wu Xing (Five Elements) Wheel

**Decision: 5 element nodes on the wheel, color-coded, with sub-selections where brewing parameters meaningfully diverge.**

The original app had 13 tea nodes on a flat wheel ordered from yang to yin. The new concept simplifies this to 5 nodes mapped to the Wu Xing elements, making the app accessible to beginners while preserving depth for enthusiasts.

### Element → Tea Mapping

| Element | Chinese | Tea Type | Sub-options | Reason for subs |
|---------|---------|----------|-------------|-----------------|
| Wood 木 | 绿茶 | Green Tea | None | One param set covers it |
| Fire 火 | 红茶 | Black Tea | None | Hong Cha is one category |
| Earth 土 | 烏龍 | Oolong | Light / Dark | 80°C High Mountain vs 100°C Yancha — completely different sessions |
| Metal 金 | 白茶 | White Tea | Fresh / Aged | 88°C no rinse vs 95°C with rinse |
| Water 水 | 普洱 | Pu-erh | Sheng / Shou | Different temps, ratios, and character |

Two nodes (Wood, Fire) go straight to brewing on selection. Three nodes (Earth, Metal, Water) show a sub-choice in the center area. Maximum two taps to start any session.

### Wheel Interaction Model

Based on the reference image (Chinese zodiac selector wheel — `Selector_wheel.png` in the project):
- Single-level wheel with bubbles arranged in a circle on a dashed orbit ring
- Yin-yang center area shows the selected tea's info
- Tap an element → it highlights, others dim, center shows tea name (or sub-choices)
- For elements without subs: tap again or tap center → start brewing
- For elements with subs: sub-choices appear in center as tappable labels, tap one → start brewing
- The sub-selection happens in-place in the center — not a new screen, not a navigation event

### Element Colors (Muted, Earthy)

These are the prototype colors. They need to be muted and warm against the dark background, not vivid:
- Wood: `#4E7E38` (forest green)
- Fire: `#96382E` (deep red)
- Earth: `#967428` (ochre/gold)
- Metal: `#B0AAA0` (warm silver)
- Water: `#385E66` (deep blue-grey)

---

## 4. Three Entry Paths → One Brewing Screen

All paths converge at the same timer/brewing experience:

### Path 1: Wheel (default)
Tap element → (optional sub-choice) → brewing screen with pre-filled params.

### Path 2: AI Advisor
Text input: "I have a Da Hong Pao from 2023" or "light floral oolong, tightly rolled." AI identifies the tea via OpenRouter, returns brewing parameters, tea name, category, and a brewing note. User taps "Start Brewing" to enter the timer.

### Path 3: Custom
Manual parameter entry: tea name, water temperature, leaf ratio, vessel size, rinse toggle, infusion schedule. Straight to brew.

Navigation between paths uses a bottom tab bar with three tabs: Wheel, AI Advisor, Custom.

---

## 5. Brewing Timer Screen

The timer is the heart of the app. It needs to feel calm — a meditation bell, not a kitchen timer.

### Layout
- Top bar: tea name (English + Chinese) on left, "End" on right
- Infusion number label
- Large circular progress ring with countdown number in center
- Play/Pause button below the ring
- Schedule preview bar at bottom (all infusion times, current highlighted)
- Brew params line: temperature · ratio · rinse status

### Timer Behavior
- Tap play → ring animates clockwise, number counts down
- Tap pause → freezes, ring stops, button changes to play
- When countdown reaches 0 → chime sound → transition to between-infusion screen

### Between-Infusion Screen
- Shows completed infusion time
- Next infusion preview with ±3s adjustment buttons (not a slider — one-handed use with wet hands)
- "Brew Next" button
- Session progress ladder (pills showing each infusion time, completed ones marked)
- No tasting tags for v1 — keep it calm

---

## 6. Design System

### Existing Palette (Carry Forward)

From the original app's `styles.css` and visual direction doc. The design thesis is "scholar's tea table at dusk" — fired clay, dark wood, warm paper, quiet steam.

```
--bg-app: #14110F         (near-black tea tray)
--bg-elevated: #1C1714    (lifted panels)
--surface-soft: #241E1A   (inputs, secondary surfaces)
--line-muted: #3A3028     (borders, dividers)
--text-primary: #E7DDCC   (warm parchment)
--text-secondary: #B7A892 (secondary labels)
--text-faint: #8E806C     (tertiary metadata)
--accent-clay: #8C563E    (primary actions, active states)
--accent-celadon: #66705F (completed states, confirmation)
--accent-gold: #c9a84c    (restrained highlights)
```

### Typography
- Chinese: Noto Serif SC (bold for characters, display)
- Latin: DM Sans (clean, geometric, warm — used in the prototype; consider alternatives during build)
- The original app used Inter — avoid for the rebuild, it's too generic for an app about craft

### What to Avoid (From Original Visual Direction Doc)
- Glossy gradients, neon glow effects
- Frosted-glass as dominant surface language
- Decorative leaf illustrations
- Brush-script gimmicks
- Red/gold "Chinese restaurant" symbolism
- 80-85% of UI should be dark neutrals; clay is the main active color

### Touch Targets
- Primary buttons: 56px min height
- Secondary buttons: 44px min height
- Chips/tags: 36px min height
- All interactive elements must work one-handed with wet fingers

---

## 7. Tea Data (Salvage from Old Project)

The `teaPresets.js` file from the existing project contains well-curated brewing parameters for 13 teas. For the new 5-element model, the relevant params are:

### Green Tea (Wood)
- Vessel: 80ml, Leaf: 5g/80ml, Temp: 80°C, Rinse: No
- Schedule: 8, 10, 12, 15, 20, 28, 38

### Black Tea (Fire)
- Vessel: 100ml, Leaf: 5.5g/100ml, Temp: 95°C, Rinse: No
- Schedule: 10, 12, 15, 18, 24, 32, 45, 62

### Light Oolong (Earth)
- Vessel: 100ml, Leaf: 5.5g/100ml, Temp: 95°C, Rinse: No
- Schedule: 10, 12, 14, 18, 24, 32, 45, 60

### Dark Oolong (Earth)
- Vessel: 100ml, Leaf: 7g/100ml, Temp: 100°C, Rinse: Yes
- Schedule: 8, 10, 12, 15, 20, 28, 38, 55

### Fresh White Tea (Metal)
- Vessel: 100ml, Leaf: 5g/100ml, Temp: 88°C, Rinse: No
- Schedule: 12, 15, 18, 22, 28, 36, 50, 70

### Aged White Tea (Metal)
- Vessel: 100ml, Leaf: 5g/100ml, Temp: 95°C, Rinse: Yes
- Schedule: 10, 12, 15, 20, 28, 38, 55, 75

### Sheng Pu-erh (Water)
- Vessel: 100ml, Leaf: 5.5g/100ml, Temp: 95°C, Rinse: Yes
- Schedule: 6, 8, 10, 12, 16, 22, 30, 45

### Shou Pu-erh (Water)
- Vessel: 110ml, Leaf: 6.4g/110ml, Temp: 100°C, Rinse: Yes
- Schedule: 10, 12, 15, 18, 24, 32, 45, 60

---

## 8. What NOT to Port from the Old Codebase

- **useBrewSession.js** — 580 lines of Vue reactive state. The algorithm is sound but it's deeply coupled to Vue's `ref()`, `watch()`, `computed()`. Rewrite the timer/session logic as a React hook from the data model up, not as a syntax translation. The new version probably doesn't need tasting tags, session summaries, or recent session history for v1.
- **SettleScreen** — deleted in the old project's own redesign plan. Don't recreate it.
- **TeaWheel.vue** — the 13-node flat wheel. Replaced by the 5-element Wu Xing wheel.
- **Layout patterns** — the old app had no shared spatial grammar. Every screen was designed in isolation. Don't inherit any layout assumptions.
- **Sprint docs** — 7 sprint files of accumulated fixes. The new project starts clean.

---

## 9. What TO Carry Forward

- The **color palette and design tokens** from `styles.css`
- The **visual direction doc** aesthetic principles (not the layout guidance): "scholar's tea table at dusk," material references (Yixing clay, charcoal tea tray, xuan paper, celadon glaze), what to avoid
- The **tea brewing parameters** listed in section 7 above
- The **brewing note** copy for each tea (well-written, poetic but useful)
- The **timer algorithm** concepts: schedule-based infusion timing, pause/resume, schedule extension beyond preset length, ±adjustment for next infusion

---

## 10. Screens (6 Total for v1)

1. **Wheel Home** — 5 Wu Xing element nodes, center preview, bottom tab bar
2. **Sub-selection state** — same wheel, selected element highlighted, center shows sub-choices
3. **Brewing Timer** — circular progress ring, countdown, pause/resume
4. **Between Infusions** — completed time, next preview with ±3s adjust, "Brew Next"
5. **AI Advisor** — text input, identification result card, "Start Brewing"
6. **Custom Mode** — parameter form fields, "Start Brewing"

No settings screen, no session history, no tasting tags for v1.

---

## 11. Prototype

An interactive React prototype (`gongfu-cha-prototype.jsx`) was built during this session. It implements all 6 screens with working wheel interaction, timer countdown, between-infusion flow, AI mock response, and custom mode. Use this as the reference for layout, spacing, interaction patterns, and visual direction during the production build.

Figma wireframes were also created at: https://www.figma.com/design/JVxFH51hi3bF5dg8NnZX3i
(Figma Starter plan limits prevent further iteration there — use the React prototype as primary reference instead.)

---

## 12. Open Questions for Next Session

- **Oolong sub-split**: "Light" and "Dark" are clear labels. But should "Light" map to High Mountain Oolong specifically, or to a general light-oxidation profile? Current decision: general profile using High Mountain params as the default.
- **Schedule extension**: when a user brews past the preset schedule length, how should new infusion times be generated? The old app used a step function (last duration + variable increment). Needs confirmation.
- **Sound design**: the timer completion chime. The old app had `useAudio.js` with a bell cue. What sound fits "scholar's tea table at dusk"?
- **Rinse flow**: for teas that require a rinse, should the app guide the user through it as a step before infusion 1, or just remind them with a note?
- **AI model selection**: which model(s) to use via OpenRouter for tea identification. Needs to be fast, accurate on tea knowledge, and cheap enough for casual use.
- **Tailwind vs bespoke CSS**: genuinely open. Tailwind is faster to build but the app's atmospheric quality matters more than dev speed. The prototype uses inline styles which are closer to bespoke CSS in spirit.
