# Gongfu Cha — Build Handoff (April 2026)

This document packages the complete design and technical context for building the Gongfu Cha tea brewing app. It combines the original planning decisions with the design review session that followed. Feed this to Claude Code alongside the codebase.

---

## 1. What This App Is

A gongfu-style tea brewing timer. The user picks a tea, the app provides curated brewing parameters (temperature, leaf ratio, infusion schedule), and guides them through multiple short steeps with a countdown timer. The aesthetic is "scholar's tea table at dusk" — dark, warm, ceramic, quiet.

---

## 2. Tech Stack

- **Next.js + React + Tailwind** (or Vite + React if keeping it simple — Next.js is for Vercel deployment convenience, not a hard requirement)
- **Framer Motion** for the wheel interaction and page transitions (optional if wheel ends up tap-only — CSS may suffice)
- **OpenRouter** for AI tea identification (server-side route, keeps API key safe)
- **No database for v1.** Tea presets are static JSON. Session state uses localStorage.
- **No Zustand.** useState/useContext handles everything.
- **PWA deferred.** Build the web app first.

---

## 3. Navigation Architecture (Revised)

**Kill the tab bar.** The original prototype had a 3-tab bottom bar (Wheel / AI Advisor / Custom). This was wrong.

### Why
- The wheel is the primary experience for ~90% of sessions. AI and Custom are edge-case fallbacks.
- A tab bar treats three paths as equals when they aren't.
- The user picks tea once, then brews for 20+ minutes. The tab bar is visible for 5 seconds of a 30-minute session.
- The tab bar fragments attention during the only moment the app needs to feel calm.

### New model
- The **wheel is the full home screen**. No tab bar. It owns the viewport.
- **AI Advisor and Custom Mode** live behind a subtle top-right affordance — a small icon that opens a bottom sheet or slide-over. Secondary tools, not primary navigation.
- All three paths still converge on the same brewing timer screen.

---

## 4. The Wu Xing Wheel (Primary Interaction)

5 element nodes mapped to tea types. This is the core selection UI.

### Element → Tea Mapping

| Element | Tea Type | Sub-options | Why subs exist |
|---------|----------|-------------|----------------|
| Wood 木 | Green Tea | None | One param set covers it |
| Fire 火 | Black Tea | None | One category |
| Earth 土 | Oolong | Light / Dark | 95°C High Mountain vs 100°C Yancha — different sessions |
| Metal 金 | White Tea | Fresh / Aged | 88°C no rinse vs 95°C with rinse |
| Water 水 | Pu-erh | Sheng / Shou | Different temps, ratios, character |

Two nodes (Wood, Fire) go straight to brewing on selection. Three nodes (Earth, Metal, Water) show a sub-choice. Maximum two taps to start any session.

### Element Colors (Muted, Earthy)
- Wood: `#4E7E38` (forest green)
- Fire: `#96382E` (deep red)
- Earth: `#967428` (ochre/gold)
- Metal: `#B0AAA0` (warm silver)
- Water: `#385E66` (deep blue-grey)

### Interaction Model
- Tap an element → it highlights, others dim, detail panel shows tea info (or sub-choices)
- For elements without subs: tap again or tap a "Brew" button → start brewing
- For elements with subs: sub-choices appear in a detail area, tap one → start brewing
- Sub-selection happens in-place — not a new screen, not a navigation event

### Critical Design Note
The previous prototype used an SVG-based wheel. **Don't do this.** SVG kills the material quality that CSS gives you (real shadows, real blur, real transitions). Build the wheel nodes as real HTML/DOM elements positioned in a circle with CSS. Each node gets proper depth, tap feedback, and transitions that SVG can't deliver.

**Names on the wheel must be in English.** Chinese characters can appear as decorative/atmospheric elements (e.g., a large faint character in the center) but the functional labels are English.

---

## 5. Three Entry Paths → One Brewing Screen

### Path 1: Wheel (default, full-screen home)
Tap element → (optional sub-choice) → brewing screen with pre-filled params.

### Path 2: AI Advisor (secondary, accessed via icon → bottom sheet)
Text input: "I have a Da Hong Pao from 2023" or "light floral oolong, tightly rolled." AI identifies the tea via OpenRouter, returns brewing parameters, tea name, category, and a brewing note. User taps "Start Brewing" to enter the timer.

### Path 3: Custom (secondary, accessed via icon → bottom sheet)
Manual parameter entry: tea name, water temperature, leaf ratio, vessel size, rinse toggle, infusion schedule. Straight to brew.

---

## 6. Brewing Timer Screen

The timer is the heart of the app. It needs to feel calm — a meditation bell, not a kitchen timer.

### Layout
- Top bar: tea name (English + Chinese) on left, "End" on right
- Infusion number label
- Large circular progress ring with countdown number in center
- Play/Pause button below the ring
- Schedule preview bar at bottom (all infusion times, current highlighted)
- Brew params line: temperature · ratio · rinse status

### Timer Behavior
- Tap play → ring animates clockwise, number counts down
- Tap pause → freezes, ring stops, button changes to play
- When countdown reaches 0 → chime sound → transition to between-infusion state

### Between-Infusion State
- Shows completed infusion time
- Next infusion preview with ±3s adjustment buttons (not a slider — one-handed use with wet hands)
- "Brew Next" button
- Session progress (pills showing each infusion time, completed ones marked)

---

## 7. Design System

### Palette ("scholar's tea table at dusk")

```
--bg-app:         #14110F    (near-black tea tray)
--bg-elevated:    #1C1714    (lifted panels)
--surface-soft:   #241E1A    (inputs, secondary surfaces)
--line-muted:     #3A3028    (borders, dividers)
--text-primary:   #E7DDCC    (warm parchment)
--text-secondary: #B7A892    (secondary labels)
--text-faint:     #8E806C    (tertiary metadata)
--accent-clay:    #8C563E    (primary actions, active states)
--accent-celadon: #66705F    (completed states, confirmation)
--accent-gold:    #c9a84c    (restrained highlights)
```

80-85% of the UI should be dark neutrals. Clay is the main active color.

### Typography
- Chinese: Noto Serif SC (bold for characters, display)
- Latin: DM Sans (clean, geometric, warm)
- Avoid Inter — too generic for an app about craft

### What to Avoid
- Glossy gradients, neon glow effects
- Frosted-glass as dominant surface language
- Decorative leaf illustrations
- Brush-script gimmicks
- Red/gold "Chinese restaurant" symbolism

### Touch Targets
- Primary buttons: 56px min height
- Secondary buttons: 44px min height
- Chips/tags: 36px min height
- All interactive elements must work one-handed with wet fingers

---

## 8. Design Engineering Principles (Emil Kowalski)

Apply these throughout. They're non-negotiable for the build quality.

### Animation Decisions

**Custom easing curves everywhere — never use built-in CSS `ease` or `ease-in`:**
```css
--ease-out:    cubic-bezier(0.23, 1, 0.32, 1);
--ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);
--ease-drawer: cubic-bezier(0.32, 0.72, 0, 1);  /* iOS-like */
```

**Duration rules:**
- Button press feedback: 100–160ms
- Tooltips, small popovers: 125–200ms
- Dropdowns, selects: 150–250ms
- Modals, drawers, sheets: 200–500ms
- UI animations stay under 300ms

**Key principles:**
- Every pressable element gets `transform: scale(0.97)` on `:active` — instant feedback
- Never animate from `scale(0)`. Start from `scale(0.95) + opacity: 0`
- `ease-out` for elements entering/exiting. `ease-in-out` for moving/morphing
- Exit faster than enter (asymmetric timing)
- Stagger delays: 30–80ms between items
- Only animate `transform` and `opacity` (GPU-accelerated, skip layout/paint)
- CSS animations for predetermined motion, JS for dynamic/interruptible
- Gate hover states behind `@media (hover: hover) and (pointer: fine)`
- Respect `prefers-reduced-motion` — reduce, don't eliminate

**What NOT to do:**
- `transition: all` — specify exact properties
- `ease-in` on any UI element — delays initial movement
- Animation on keyboard-initiated actions
- Duration > 300ms on standard UI transitions
- Framer Motion `x`/`y` shorthand props (not hardware-accelerated) — use full `transform` strings

### Component Patterns
- Popovers/sheets scale from their trigger (origin-aware)
- Use CSS transitions over keyframes for dynamic UI (transitions retarget mid-animation; keyframes restart)
- `translateY(100%)` = element's own height — use for sheets/drawers
- `fontVariantNumeric: "tabular-nums"` on all number displays so digits don't dance
- Blur (`filter: blur(2px)`) masks imperfect crossfades

---

## 9. Tea Data (Complete)

### Green Tea (Wood 木)
- Vessel: 80ml, Leaf: 5g/80ml, Temp: 80°C, Rinse: No
- Schedule: 8, 10, 12, 15, 20, 28, 38
- Note: "No rinse, lower temp. The first steep is the brightest."

### Black Tea (Fire 火)
- Vessel: 100ml, Leaf: 5.5g/100ml, Temp: 95°C, Rinse: No
- Schedule: 10, 12, 15, 18, 24, 32, 45, 62
- Note: "Start steady, then widen as the sweetness softens."

### Light Oolong (Earth 土 · 清香)
- Vessel: 100ml, Leaf: 5.5g/100ml, Temp: 95°C, Rinse: No
- Schedule: 10, 12, 14, 18, 24, 32, 45, 60
- Note: "No rinse — preserve the first flush of fragrance."

### Dark Oolong (Earth 土 · 浓香)
- Vessel: 100ml, Leaf: 7g/100ml, Temp: 100°C, Rinse: Yes
- Schedule: 8, 10, 12, 15, 20, 28, 38, 55
- Note: "Let the roast open gradually. Early steeps stay short."

### Fresh White Tea (Metal 金 · 新)
- Vessel: 100ml, Leaf: 5g/100ml, Temp: 88°C, Rinse: No
- Schedule: 12, 15, 18, 22, 28, 36, 50, 70
- Note: "White tea rewards patience and a gentle, slow curve."

### Aged White Tea (Metal 金 · 老)
- Vessel: 100ml, Leaf: 5g/100ml, Temp: 95°C, Rinse: Yes
- Schedule: 10, 12, 15, 20, 28, 38, 55, 75
- Note: "Higher heat unlocks the jujube and wood notes."

### Sheng Pu-erh (Water 水 · 生)
- Vessel: 100ml, Leaf: 5.5g/100ml, Temp: 95°C, Rinse: Yes
- Schedule: 6, 8, 10, 12, 16, 22, 30, 45
- Note: "Short, careful steeps keep the bitterness in check."

### Shou Pu-erh (Water 水 · 熟)
- Vessel: 110ml, Leaf: 6.4g/110ml, Temp: 100°C, Rinse: Yes
- Schedule: 10, 12, 15, 18, 24, 32, 45, 60
- Note: "A double rinse clears pile notes. Let the middle steeps linger."

---

## 10. Screens (6 Total for v1)

1. **Wheel Home** — full-screen, 5 Wu Xing element nodes, detail panel for selected tea, subtle access to AI/Custom
2. **Sub-selection state** — same screen, selected element highlighted, detail area shows sub-choices
3. **Brewing Timer** — circular progress ring, countdown, pause/resume
4. **Between Infusions** — completed time, next preview with ±3s adjust, "Brew Next"
5. **AI Advisor** — bottom sheet or slide-over, text input, identification result card, "Start Brewing"
6. **Custom Mode** — bottom sheet or slide-over, parameter form fields, "Start Brewing"

No settings screen, no session history, no tasting tags for v1.

---

## 11. Open Questions

- **Schedule extension**: when a user brews past the preset schedule length, how should new infusion times be generated? The old app used a step function (last duration + variable increment).
- **Sound design**: the timer completion chime. What sound fits "scholar's tea table at dusk"?
- **Rinse flow**: for teas that require a rinse, should the app guide the user through it as a step before infusion 1, or just remind them with a note?
- **AI model selection**: which model(s) to use via OpenRouter for tea identification.
- **Tailwind vs bespoke CSS**: genuinely open. Tailwind is faster to build but the app's atmospheric quality matters. The palette and design tokens are defined — the question is whether Tailwind utilities can express the warmth and depth, or if custom CSS is needed for the soul of it.

---

## 12. Reference Files

- `DECISIONS.md` — original planning session (full context on rationale)
- `gongfu-cha-prototype.jsx` — working React prototype with all screens, timer logic, wheel interaction. Use as reference for data model and timer algorithm, not for UI/layout.
- `Selector_wheel.png` — Chinese zodiac selector wheel that inspired the node-on-orbit layout. The circular arrangement with bubbles and a center display area is the right spatial idea. Adapt it with DOM elements, not SVG.
